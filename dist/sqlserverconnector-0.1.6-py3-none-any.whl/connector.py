import os
import pandas as pd
import numpy as np
import uuid
import sqlalchemy
from typing import List, Optional, Dict, Union, Any
from loguru import logger
from sqlalchemy import create_engine, text, URL, inspect
from sqlalchemy.types import NVARCHAR, FLOAT, INTEGER, DATE, DATETIME, BIGINT
from sqlalchemy.exc import SQLAlchemyError

class SQLServerConnector:
    """
    Trình kết nối SQL Server tối ưu cho ETL (Extract-Transform-Load).
    
    Tính năng:
    - Hỗ trợ Upsert (Merge) hiệu năng cao qua bảng tạm.
    - Hỗ trợ Unicode (Tiếng Việt) tự động bằng NVARCHAR.
    - Tự động quản lý Schema và Primary Key.
    """

    def __init__(self, server: str, database: str, username: str, password: str, driver: str = 'ODBC Driver 17 for SQL Server'):
        self.server = server
        self.database = database
        self.username = username
        self.password = password
        self.driver = driver
        
        # Tạo URL kết nối
        self.connection_url = URL.create(
            "mssql+pyodbc",
            query={
                "odbc_connect": (
                    f"DRIVER={self.driver};"
                    f"SERVER={self.server};"
                    f"DATABASE={self.database};"
                    f"UID={self.username};"
                    f"PWD={self.password};"
                    "Encrypt=no;TrustServerCertificate=yes;" # Cấu hình SSL linh hoạt
                )
            }
        )
        
        # Tạo Engine với fast_executemany=True để tăng tốc độ Insert/Upsert
        self.engine = create_engine(
            self.connection_url,
            fast_executemany=True, # QUAN TRỌNG: Tăng tốc độ ghi gấp nhiều lần
            pool_pre_ping=True     # Tự động kết nối lại nếu mất kết nối
        )

    def get_data(self, query: str, params: Optional[Dict] = None, chunksize: Optional[int] = None) -> Union[pd.DataFrame, Any]:
        """
        Thực thi câu lệnh SELECT và trả về DataFrame.
        """
        try:
            with self.engine.connect() as conn:
                # Dùng text() để đảm bảo tương thích SQLAlchemy 2.0
                sql_query = text(query)
                return pd.read_sql(sql_query, conn, params=params, chunksize=chunksize)
        except Exception as e:
            logger.error(f"Failed to retrieve data: {e}")
            raise

    def execute_query(self, query: str, params: Optional[Dict] = None):
        """Thực thi câu lệnh không trả về dữ liệu (UPDATE, DELETE, SP...)."""
        try:
            with self.engine.begin() as conn: # Tự động commit
                conn.execute(text(query), params or {})
        except Exception as e:
            logger.error(f"Failed to execute query: {e}")
            raise

    def _generate_dtype_mapping(self, df: pd.DataFrame) -> Dict:
        """
        Tự động tạo mapping kiểu dữ liệu cho SQL.
        QUAN TRỌNG: Map tất cả cột string/object sang NVARCHAR để hỗ trợ Tiếng Việt.
        """
        dtype_map = {}
        for col in df.columns:
            # Nếu là chuỗi -> NVARCHAR (hỗ trợ Unicode)
            if df[col].dtype == 'object' or pd.api.types.is_string_dtype(df[col]):
                # Tính độ dài max thực tế để tối ưu, hoặc để None (NVARCHAR(MAX))
                max_len = df[col].astype(str).map(len).max()
                if pd.isna(max_len) or max_len == 0:
                    length = 255
                else:
                    length = int(max_len * 1.5) + 50 # Buffer thêm
                    if length > 4000: length = None # NVARCHAR(MAX)
                
                dtype_map[col] = NVARCHAR(length=length)
            
            # Nếu là ngày tháng
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                dtype_map[col] = DATETIME()
            
            # Số thực
            elif pd.api.types.is_float_dtype(df[col]):
                dtype_map[col] = FLOAT()
                
            # Số nguyên
            elif pd.api.types.is_integer_dtype(df[col]):
                dtype_map[col] = BIGINT()
                
        return dtype_map

    def upsert_data(self, df: pd.DataFrame, table_name: str, pk_cols: List[str]):
        """
        Thực hiện Upsert (Insert hoặc Update) dữ liệu vào bảng SQL Server.
        Sử dụng cơ chế Bảng Tạm (Staging Table) + MERGE Statement.
        """
        if df.empty:
            logger.warning(f"DataFrame for table {table_name} is empty. Skipping upsert.")
            return

        # 1. Chuẩn bị tên bảng tạm
        staging_table = f"##Staging_{uuid.uuid4().hex[:8]}"
        
        # 2. Tạo mapping kiểu dữ liệu (Fix lỗi Unicode)
        dtype_mapping = self._generate_dtype_mapping(df)

        try:
            with self.engine.begin() as conn:
                # A. Đẩy dữ liệu vào bảng tạm (Staging)
                # fast_executemany=True ở engine sẽ làm bước này cực nhanh
                df.to_sql(
                    name=staging_table,
                    con=conn,
                    if_exists='replace',
                    index=False,
                    dtype=dtype_mapping # Ép kiểu NVARCHAR tại đây
                )

                # B. Kiểm tra bảng đích có tồn tại không
                inspector = inspect(conn)
                if not inspector.has_table(table_name):
                    logger.info(f"Table {table_name} does not exist. Creating from staging...")
                    # Tạo bảng chính từ bảng tạm (Copy cấu trúc và dữ liệu)
                    # Lưu ý: SELECT INTO sẽ tạo bảng mới
                    create_sql = f"SELECT * INTO {table_name} FROM {staging_table}"
                    conn.execute(text(create_sql))
                    
                    # Tạo Primary Key cho bảng mới
                    if pk_cols:
                        pk_str = ", ".join([f"[{c}]" for c in pk_cols])
                        try:
                            alter_pk = f"ALTER TABLE {table_name} ADD CONSTRAINT PK_{table_name}_{uuid.uuid4().hex[:4]} PRIMARY KEY ({pk_str})"
                            conn.execute(text(alter_pk))
                        except Exception as ex_pk:
                            logger.warning(f"Could not create PK: {ex_pk}")
                else:
                    # C. Thực hiện MERGE (Upsert)
                    # Lấy danh sách cột
                    cols = [c for c in df.columns]
                    
                    # 1. Điều kiện ON (Primary Keys)
                    on_clause = " AND ".join([f"Target.[{col}] = Source.[{col}]" for col in pk_cols])
                    
                    # 2. Điều kiện UPDATE (Các cột không phải PK)
                    update_cols = [col for col in cols if col not in pk_cols]
                    if update_cols:
                        update_clause = ", ".join([f"Target.[{col}] = Source.[{col}]" for col in update_cols])
                        matched_action = f"WHEN MATCHED THEN UPDATE SET {update_clause}"
                    else:
                        # Trường hợp bảng chỉ có PK (ít gặp), không làm gì khi match
                        matched_action = ""

                    # 3. Điều kiện INSERT (Tất cả cột)
                    insert_cols_str = ", ".join([f"[{col}]" for col in cols])
                    insert_vals_str = ", ".join([f"Source.[{col}]" for col in cols])

                    merge_sql = f"""
                    MERGE [{table_name}] AS Target
                    USING {staging_table} AS Source
                    ON {on_clause}
                    {matched_action}
                    WHEN NOT MATCHED BY TARGET THEN
                        INSERT ({insert_cols_str}) 
                        VALUES ({insert_vals_str});
                    """
                    
                    conn.execute(text(merge_sql))
                    logger.info(f"Upserted {len(df)} rows into {table_name}.")

                # D. Xóa bảng tạm (Optional, vì temp table ## tự hủy khi đóng conn, nhưng xóa cho sạch)
                conn.execute(text(f"DROP TABLE IF EXISTS {staging_table}"))
                
        except Exception as e:
            logger.error(f"Upsert failed for {table_name}: {e}")
            raise

    def dispose(self):
        self.engine.dispose()